
#include <stdio.h>
int nguyenTo(int n) {
    if (n < 2)
        return 0;
    for (int i = 2; i * i <= n; i++)
        if (n % i == 0)
            return 0;
    return 1;
}

int main() {
    int n, m;
    int a[50][50];
    int dem = 0;
    scanf("%d%d", &n, &m);
    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++)
            scanf("%d", &a[i][j]);
    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++)
            if (nguyenTo(a[i][j]))
                dem++;
    printf("%d", dem);
    return 0;
}
