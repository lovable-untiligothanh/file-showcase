
#include <stdio.h>
#include <string.h>
int gcd(long long a, long long b) {
    while (b != 0) {
        long long temp = a % b;
        a = b;
        b = temp;
    }
    return a;
}
int main() {
    int t;
    scanf("%d", &t);
    while (t--) {
        char s[20];
        scanf("%s", s);
        int n = strlen(s);
        if (n % 2 != 0) {
            printf("INVALID\n");
            continue;
        }
        long long left = 0;
        long long right = 0;
        for (int i = 0; i < n / 2; i++)
            left = left * 10 + (s[i] - '0');
        for (int i = n / 2; i < n; i++)
            right = right * 10 + (s[i] - '0');
        printf("%lld\n", gcd(left, right));
    }
    return 0;
}
