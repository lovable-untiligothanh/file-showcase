#include <stdio.h>
int main() {
    int n, a[100];
    int daXuatHien[100] = {0};
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
        scanf("%d", &a[i]);
    for (int i = 0; i < n; i++) {
        if (daXuatHien[i] == 1)
            continue;
        int dem = 0;
        for (int j = i; j < n; j++) {
            if (a[i] == a[j]) {
                dem++;
                daXuatHien[j] = 1;
            }
        }
        printf("%d %d\n", a[i], dem);
    }

    return 0;
}
