#include<stdio.h>
int main() {
    int n, i, x, a[1000] = {0};
    scanf("%d", &n);
    for(i=0; i<n; i++) {
        scanf("%d", &x);
        a[x]++;
    }
    for(i=0; i<1000; i++)
        if(a[i] > 0)
            printf("%d ", i);
    return 0;
}
