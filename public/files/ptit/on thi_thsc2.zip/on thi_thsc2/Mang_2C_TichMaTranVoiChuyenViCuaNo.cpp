#include <stdio.h>

int main() {
    int t;
    scanf("%d", &t);
    for (int test = 1; test <= t; test++) {
        int n, m;
        int a[50][50];
        long long c[50][50];
        scanf("%d%d", &n, &m);
        // Nhập ma trận A
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++)
                scanf("%d", &a[i][j]);
        // Tính A * A chuyển vị
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                c[i][j] = 0;
                for (int k = 0; k < m; k++)
                    c[i][j] += (long long)a[i][k] * a[j][k];
            }
        }
        // In số thứ tự test
        printf("Test %d:\n", test);
        // In kết quả
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++)
                printf("%lld ", c[i][j]);
            printf("\n");
        }
    }

    return 0;
}

