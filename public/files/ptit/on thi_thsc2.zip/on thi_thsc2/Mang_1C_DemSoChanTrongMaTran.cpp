#include <stdio.h>

int main() {
    int n, m;
    int a[50][50];
    int dem = 0;

    scanf("%d%d", &n, &m);

    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++)
            scanf("%d", &a[i][j]);

    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++)
            if (a[i][j] % 2 == 0)
                dem++;

    printf("%d", dem);

    return 0;
}
