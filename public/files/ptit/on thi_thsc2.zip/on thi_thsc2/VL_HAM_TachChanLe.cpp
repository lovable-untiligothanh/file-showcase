#include <stdio.h>

int main() {
    int n;
    int a[100];
    int chan[100], le[100];
    int nc = 0, nl = 0;
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
        if (a[i] % 2 == 0) {
            chan[nc] = a[i];
            nc++;
        } else {
            le[nl] = a[i];
            nl++;
        }
    }
    // In số chẵn
    for (int i = 0; i < nc; i++)
        printf("%d ", chan[i]);
    printf("\n");
    // In số lẻ
    for (int i = 0; i < nl; i++)
        printf("%d ", le[i]);
    return 0;
}
