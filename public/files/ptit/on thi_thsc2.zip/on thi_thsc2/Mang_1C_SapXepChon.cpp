#include <stdio.h>

int main() {
    int n, a[100];
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
        scanf("%d", &a[i]);
    for (int i = 0; i < n - 1; i++) {
        int min = i;
        // Tìm phần tử nhỏ nhất
        for (int j = i + 1; j < n; j++) {
            if (a[j] < a[min])
                min = j;
        }
        // Đổi chỗ
        int temp = a[i];
        a[i] = a[min];
        a[min] = temp;
        // In từng bước
        printf("Buoc %d: ", i + 1);
        for (int j = 0; j < n; j++)
            printf("%d ", a[j]);
        printf("\n");
    }
    return 0;
}
