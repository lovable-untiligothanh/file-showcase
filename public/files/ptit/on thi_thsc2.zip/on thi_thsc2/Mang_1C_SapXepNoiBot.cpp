#include <stdio.h>

int main() {
    int n, a[100];
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
        scanf("%d", &a[i]);
    int buoc = 1;
    for (int i = 0; i < n - 1; i++) {
        int doi = 0;
        for (int j = 0; j < n - 1 - i; j++) {
            if (a[j] > a[j + 1]) {
                int temp = a[j];
                a[j] = a[j + 1];
                a[j + 1] = temp;
                doi = 1;
            }
        }
        if (doi == 1) {
            printf("Buoc %d: ", buoc);

            for (int j = 0; j < n; j++)
                printf("%d ", a[j]);
            printf("\n");
            buoc++;
        }
    }
    return 0;
}

