
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    char s[205];
    scanf("%s", s);
    while (strlen(s) > 1) {
        int n = strlen(s);
        int mid = n / 2;
        char a[205], b[205];
        // Tách nửa đầu
        for (int i = 0; i < mid; i++)
            a[i] = s[i];
        a[mid] = '\0';
        // Tách nửa sau
        int j = 0;
        for (int i = mid; i < n; i++) {
            b[j] = s[i];
            j++;
        }
        b[j] = '\0';
        // Chuyển thành số
        long long x = atoll(a);
        long long y = atoll(b);
        // Cộng
        long long sum = x + y;
        printf("%lld\n", sum);
        // Đưa kết quả về chuỗi để tiếp tục
        sprintf(s, "%lld", sum);
    }
    return 0;
}


