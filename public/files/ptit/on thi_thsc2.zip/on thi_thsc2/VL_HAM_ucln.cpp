#include <stdio.h>
#include <stdlib.h> // Để dùng hàm abs() xử lý số âm

// Hàm tính Ước số chung lớn nhất
int ucln(int a, int b) {
    a = abs(a); // Đổi sang số dương vì ƯCLN luôn >= 0
    b = abs(b);

    while (b != 0) {
        int r = a % b;
        a = b;
        b = r;
    }
    return a;
}

int main() {
    int a, b;
    printf("Nhap hai so a va b: ");
    scanf("%d %d", &a, &b);

    printf("UCLN(%d, %d) = %d\n", a, b, ucln(a, b));

    return 0;
}
