#include <stdio.h>
#include <string.h>

int main() {
    int t;
    scanf("%d", &t);
    while (t--) {
        char a[505], b[505], c[510];
        scanf("%s", a);
        scanf("%s", b);
        int i = strlen(a) - 1;
        int j = strlen(b) - 1;
        int k = 0;
        int nho = 0;
        while (i >= 0 || j >= 0) {
            int x = 0, y = 0;

            if (i >= 0)
                x = a[i--] - '0';

            if (j >= 0)
                y = b[j--] - '0';

            int tong = x + y + nho;

            c[k] = tong % 10 + '0';
            nho = tong / 10;
            k++;
        }

        if (nho > 0) {
            c[k] = nho + '0';
            k++;
        }
        // Đảo chuỗi kết quả
        for (int l = 0; l < k / 2; l++) {
            char temp = c[l];
            c[l] = c[k - 1 - l];
            c[k - 1 - l] = temp;
        }

        c[k] = '\0';

        printf("%s\n", c);
    }

    return 0;
}
