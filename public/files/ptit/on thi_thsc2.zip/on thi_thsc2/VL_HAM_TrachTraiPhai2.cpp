#include <stdio.h>
int main() {
    int t;
    scanf("%d", &t);
    while (t--) {
        long long n, temp, p = 1;
        int dem = 0;
        scanf("%lld", &n);
        temp = n;
        // Đếm số chữ số
        while (temp > 0) {
            dem++;
            temp /= 10;
        }
        if (dem % 2 == 1) {
            printf("INVALID\n");
            continue;
        }
        // p = 10^(dem/2)
        for (int i = 0; i < dem / 2; i++) {
            p *= 10;
        }
        // Tách hai nửa
        long long trai = n / p;
        long long phai = n % p;
        // Tìm UCLN
        long long a = trai;
        long long b = phai;
        while (b != 0) {
            long long r = a % b;
            a = b;
            b = r;
        }
        // BCNN
        long long ketqua = trai / a * phai;
        printf("%lld\n", ketqua);
    }
    return 0;
}
