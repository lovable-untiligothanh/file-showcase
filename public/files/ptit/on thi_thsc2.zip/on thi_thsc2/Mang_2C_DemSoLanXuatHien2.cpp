
#include <stdio.h>
int nguyenTo(int n) {
    if (n < 2)
        return 0;
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0)
            return 0;
    }
    return 1;
}

int main() {
    int t;
    scanf("%d", &t);
    for (int test = 1; test <= t; test++) {
        int n, a[100];
        int daDem[100] = {0};
        scanf("%d", &n);
        for (int i = 0; i < n; i++)
            scanf("%d", &a[i]);
        printf("Test %d:\n", test);
        for (int i = 0; i < n; i++) {
            // Không phải số nguyên tố
            if (!nguyenTo(a[i]))
                continue;
            // Đã đếm rồi
            if (daDem[i])
                continue;
            int dem = 0;
            for (int j = i; j < n; j++) {
                if (a[i] == a[j]) {
                    dem++;
                    daDem[j] = 1;
                }
            }
            printf("%d %d\n", a[i], dem);
        }
    }

    return 0;
}
