#include <stdio.h>

int main() {
    int n, a[100];
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
        scanf("%d", &a[i]);
    // Bước 0
    printf("Buoc 0: %d\n", a[0]);
    for (int i = 1; i < n; i++) {
        int x = a[i];
        int j = i - 1;
        // Dịch các phần tử lớn hơn x sang phải
        while (j >= 0 && a[j] > x) {
            a[j + 1] = a[j];
            j--;
        }
        // Chèn x vào vị trí đúng
        a[j + 1] = x;
        // In bước hiện tại
        printf("Buoc %d: ", i);
        for (int k = 0; k <= i; k++)
            printf("%d ", a[k]);
        printf("\n");
    }

    return 0;
}

