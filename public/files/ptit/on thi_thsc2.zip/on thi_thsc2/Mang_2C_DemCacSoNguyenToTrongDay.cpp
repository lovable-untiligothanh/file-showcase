#include <stdio.h>
int nguyenTo(int n) {
    if (n < 2)
        return 0;
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0)
            return 0;
    }
    return 1;
}

int main() {
    int t;
    scanf("%d", &t);
    for (int test = 1; test <= t; test++) {
        int n;
        int a[100];
        int dem[10001] = {0};
        scanf("%d", &n);
        for (int i = 0; i < n; i++) {
            scanf("%d", &a[i]);
            dem[a[i]]++;
        }
        printf("Test %d:\n", test);
        for (int i = 2; i <= 10000; i++) {
            if (nguyenTo(i) && dem[i] > 0) {
                printf("%d %d\n", i, dem[i]);
            }
        }
    }

    return 0;
}
