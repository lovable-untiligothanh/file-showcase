#include <stdio.h>
#include <stdbool.h>
#include <math.h>

bool isPrime(int n) {
    if (n <= 1) return false; // Các số <= 1 không phải là số nguyên tố

    // Chạy từ 2 đến căn bậc hai của n
    for (int i = 2; i <= sqrt(n); i++) {
        if (n % i == 0) {
            return false; // Nếu chia hết cho i thì không phải số nguyên tố
        }
    }
    return true; // Nếu không chia hết cho số nào thì là số nguyên tố
}

int main() {
    int n;
    printf("Nhap so can kiem tra: ");
    scanf("%d", &n);
    if (isPrime(n)) {
        printf("%d la so nguyen to.\n", n);
    } else {
        printf("%d khong phai la so nguyen to.\n", n);
    }
    return 0;
}
