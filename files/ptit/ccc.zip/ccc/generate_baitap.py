#!/usr/bin/env python3
import json
import os
import re
import subprocess
from html import unescape

BASE = "https://thuchanh.pttc1.edu.vn"
TOKEN = "11866|tBTTbAGwFAbfF6LwLUHRlLLAAykIL47eTbj4RObK"
HEADERS = {
    "authorization": f"Bearer {TOKEN}",
    "accept": "application/json, text/plain, */*",
    "content-type": "application/json",
    "referer": f"{BASE}/student/question",
    "user-agent": "Mozilla/5.0",
}

OUT_DIR = "baitap"
os.makedirs(OUT_DIR, exist_ok=True)


def api_get(path: str):
    cmd = [
        "curl",
        "-sS",
        "--retry",
        "3",
        "--retry-delay",
        "1",
        BASE + path,
    ]
    for k, v in HEADERS.items():
        cmd.extend(["-H", f"{k}: {v}"])
    out = subprocess.check_output(cmd, text=True)
    return json.loads(out)


def clean_code(text: str) -> str:
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = unescape(text)
    text = re.sub(r"```(?:c|cpp|c\+\+)?", "", text, flags=re.IGNORECASE)
    text = text.replace("```", "")
    return text.strip() + "\n"


def code_score(src: str):
    s = src.lower()
    if "#include" not in s or "main(" not in s:
        return -10_000
    score = 0
    if "<stdio.h>" in s:
        score += 120
    if "printf(" in s or "scanf(" in s:
        score += 80
    if "iostream" in s or "using namespace std" in s or "cout" in s or "cin" in s:
        score -= 120
    if "bits/stdc++.h" in s:
        score -= 40
    if "vector<" in s or "string " in s or "std::" in s:
        score -= 30
    if "int main" in s:
        score += 5
    return score


def is_probably_c(src: str):
    s = src.lower()
    if "iostream" in s or "using namespace std" in s or "cout" in s or "cin" in s:
        return False
    return "#include" in s and "main(" in s


list_data = api_get("/api/questions?course_id=70&page=1&per_page=100&s=")
questions = list_data.get("data", [])

report = {
    "total": len(questions),
    "written": 0,
    "from_comments": 0,
    "probably_c": 0,
    "fallback": 0,
    "missing": [],
}

for q in questions:
    code = q["code"]
    detail = api_get(f"/api/questions/{code}?course_id=70")
    qd = detail.get("data", {})
    comments = qd.get("comments", []) or []

    candidates = []
    for c in comments:
        content = c.get("content") or ""
        cleaned = clean_code(content)
        score = code_score(cleaned)
        if score > -10_000:
            candidates.append((score, cleaned))

    candidates.sort(key=lambda x: x[0], reverse=True)

    chosen = None
    if candidates:
        chosen = candidates[0][1]
        report["from_comments"] += 1
    else:
        md = (qd.get("md_content") or "").strip()
        md = re.sub(r"\s+", " ", md)
        chosen = (
            "#include <stdio.h>\n\n"
            "int main() {\n"
            "    // Chua tim duoc loi giai C tu du lieu cong khai.\n"
            f"    // Ma bai: {code}\n"
            f"    // De bai tom tat: {md[:220]}\n"
            "    return 0;\n"
            "}\n"
        )
        report["fallback"] += 1
        report["missing"].append(code)

    path = os.path.join(OUT_DIR, f"{code}.c")
    with open(path, "w", encoding="utf-8") as f:
        f.write(chosen)

    report["written"] += 1
    if is_probably_c(chosen):
        report["probably_c"] += 1

with open(os.path.join(OUT_DIR, "_report.json"), "w", encoding="utf-8") as f:
    json.dump(report, f, ensure_ascii=False, indent=2)

print(json.dumps(report, ensure_ascii=False))
