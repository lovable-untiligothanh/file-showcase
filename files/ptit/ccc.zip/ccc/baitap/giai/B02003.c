#include <stdio.h>

long long ham_1(long long bien_1, long long bien_2) {
    while (bien_2 != 0) {
        long long bien_3 = bien_1 % bien_2;
        bien_1 = bien_2;
        bien_2 = bien_3;
    }
    return bien_1;
}

int main() {
    long long bien_1, bien_2;
    scanf("%lld%lld", &bien_1, &bien_2);
    long long bien_4 = ham_1(bien_1, bien_2);
    long long bien_5 = bien_1 / bien_4 * bien_2;
    printf("%lld\n%lld", bien_4, bien_5);
    return 0;
}
