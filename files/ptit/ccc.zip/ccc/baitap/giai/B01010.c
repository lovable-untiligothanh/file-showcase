#include <stdio.h>
#include <math.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);
    while (bien_1--) {
        double bien_2, bien_3, bien_4, bien_5;
        scanf("%lf%lf%lf%lf", &bien_2, &bien_3, &bien_4, &bien_5);
        double bien_6 = bien_2 - bien_4;
        double bien_7 = bien_3 - bien_5;
        printf("%.6f\n", sqrt(bien_6 * bien_6 + bien_7 * bien_7));
    }
    return 0;
}
