#include <stdio.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);
    while (bien_1--) {
        char bien_2[100005];
        scanf("%s", bien_2);

        int bien_3[26] = {0};
        int bien_4 = 0;
        for (int bien_5 = 0; bien_2[bien_5]; ++bien_5) {
            if (bien_2[bien_5] >= 'A' && bien_2[bien_5] <= 'Z') bien_3[bien_2[bien_5] - 'A']++;
            else bien_4 += bien_2[bien_5] - '0';
        }

        for (int bien_6 = 0; bien_6 < 26; ++bien_6)
            for (int bien_7 = 0; bien_7 < bien_3[bien_6]; ++bien_7)
                putchar('A' + bien_6);

        printf("%d\n", bien_4);
    }
    return 0;
}
