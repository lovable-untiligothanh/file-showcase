#include <stdio.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);

    long long bien_2 = 0, bien_3 = 1;
    for (int bien_4 = 0; bien_4 < bien_1; ++bien_4) {
        if (bien_4) printf(" ");
        if (bien_4 == 0) {
            printf("0");
        } else if (bien_4 == 1) {
            printf("1");
        } else {
            long long bien_5 = bien_2 + bien_3;
            bien_2 = bien_3;
            bien_3 = bien_5;
            printf("%lld", bien_3);
        }
    }

    return 0;
}
