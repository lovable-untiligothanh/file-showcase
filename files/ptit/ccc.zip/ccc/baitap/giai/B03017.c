#include <stdio.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);
    for (int bien_2 = 1; bien_2 <= bien_1; ++bien_2) {
        int bien_3, bien_4;
        scanf("%d%d", &bien_3, &bien_4);

        long long A[55][55], C[55][55];
        for (int bien_5 = 0; bien_5 < bien_3; ++bien_5)
            for (int bien_6 = 0; bien_6 < bien_4; ++bien_6)
                scanf("%lld", &A[bien_5][bien_6]);

        for (int bien_5 = 0; bien_5 < bien_3; ++bien_5) {
            for (int bien_6 = 0; bien_6 < bien_3; ++bien_6) {
                C[bien_5][bien_6] = 0;
                for (int bien_7 = 0; bien_7 < bien_4; ++bien_7) C[bien_5][bien_6] += A[bien_5][bien_7] * A[bien_6][bien_7];
            }
        }

        printf("Test %d:\n", bien_2);
        for (int bien_5 = 0; bien_5 < bien_3; ++bien_5) {
            for (int bien_6 = 0; bien_6 < bien_3; ++bien_6) {
                if (bien_6) printf(" ");
                printf("%lld", C[bien_5][bien_6]);
            }
            printf("\n");
        }
    }
    return 0;
}
