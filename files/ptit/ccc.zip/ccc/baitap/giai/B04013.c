#include <stdio.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);
    while (bien_1--) {
        char bien_2[205];
        scanf("%s", bien_2);

        for (int bien_3 = 0; bien_2[bien_3]; bien_3 += 2) {
            char bien_4 = bien_2[bien_3];
            int bien_5 = bien_2[bien_3 + 1] - '0';
            for (int bien_6 = 0; bien_6 < bien_5; ++bien_6) putchar(bien_4);
        }
        putchar('\n');
    }
    return 0;
}
