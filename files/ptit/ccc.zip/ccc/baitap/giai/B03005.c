#include <stdio.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);
    int bien_2[105];
    for (int bien_3 = 0; bien_3 < bien_1; ++bien_3) scanf("%d", &bien_2[bien_3]);

    int bien_4[105] = {0};
    for (int bien_3 = 0; bien_3 < bien_1; ++bien_3) {
        if (bien_4[bien_3]) continue;
        int bien_5 = 1;
        for (int bien_6 = bien_3 + 1; bien_6 < bien_1; ++bien_6) {
            if (bien_2[bien_6] == bien_2[bien_3]) {
                bien_5++;
                bien_4[bien_6] = 1;
            }
        }
        printf("%d %d\n", bien_2[bien_3], bien_5);
    }

    return 0;
}
