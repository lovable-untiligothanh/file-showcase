#include <stdio.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);

    int bien_2[105][105];
    int bien_3 = 0, bien_4 = bien_1 - 1, bien_5 = 0, bien_6 = bien_1 - 1;
    int bien_7 = 1;

    while (bien_3 <= bien_4 && bien_5 <= bien_6) {
        for (int bien_8 = bien_5; bien_8 <= bien_6; ++bien_8) bien_2[bien_3][bien_8] = bien_7++;
        bien_3++;

        for (int bien_9 = bien_3; bien_9 <= bien_4; ++bien_9) bien_2[bien_9][bien_6] = bien_7++;
        bien_6--;

        if (bien_3 <= bien_4) {
            for (int bien_8 = bien_6; bien_8 >= bien_5; --bien_8) bien_2[bien_4][bien_8] = bien_7++;
            bien_4--;
        }

        if (bien_5 <= bien_6) {
            for (int bien_9 = bien_4; bien_9 >= bien_3; --bien_9) bien_2[bien_9][bien_5] = bien_7++;
            bien_5++;
        }
    }

    for (int bien_9 = 0; bien_9 < bien_1; ++bien_9) {
        for (int bien_8 = 0; bien_8 < bien_1; ++bien_8) {
            if (bien_8) printf(" ");
            printf("%d", bien_2[bien_9][bien_8]);
        }
        printf("\n");
    }

    return 0;
}
