#include <stdio.h>

int main()
{
    int bien_1, bien_2;
    scanf("%d %d", &bien_1, &bien_2);
    printf("%d\n", bien_1 + bien_2);
}
