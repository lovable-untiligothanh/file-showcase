#include <stdio.h>

long long ham_1(long long bien_1) {
    long long bien_2 = 0;
    while (bien_1 > 0) {
        bien_2 = bien_2 * 10 + bien_1 % 10;
        bien_1 /= 10;
    }
    return bien_2;
}

int ham_2(long long bien_1) {
    return bien_1 == ham_1(bien_1);
}

int main() {
    long long bien_3, bien_4;
    scanf("%lld%lld", &bien_3, &bien_4);
    printf((ham_2(bien_3) ^ ham_2(bien_4)) ? "YES" : "NO");
    return 0;
}
