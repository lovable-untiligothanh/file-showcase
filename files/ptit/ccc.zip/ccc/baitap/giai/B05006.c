#include <stdio.h>
#include <string.h>

typedef struct {
    char bien_1[20];
    char bien_2[60];
    char bien_3[20];
    double bien_4, bien_5, bien_6;
} Student;

int main() {
    int bien_11;
    scanf("%d", &bien_11);
    getchar();

    Student bien_7[105];
    for (int bien_12 = 0; bien_12 < bien_11; ++bien_12) {
        fgets(bien_7[bien_12].bien_1, sizeof(bien_7[bien_12].bien_1), stdin);
        fgets(bien_7[bien_12].bien_2, sizeof(bien_7[bien_12].bien_2), stdin);
        fgets(bien_7[bien_12].bien_3, sizeof(bien_7[bien_12].bien_3), stdin);

        bien_7[bien_12].bien_1[strcspn(bien_7[bien_12].bien_1, "\n")] = '\0';
        bien_7[bien_12].bien_2[strcspn(bien_7[bien_12].bien_2, "\n")] = '\0';
        bien_7[bien_12].bien_3[strcspn(bien_7[bien_12].bien_3, "\n")] = '\0';

        scanf("%lf%lf%lf", &bien_7[bien_12].bien_4, &bien_7[bien_12].bien_5, &bien_7[bien_12].bien_6);
        getchar();
    }

    for (int bien_12 = 0; bien_12 < bien_11 - 1; ++bien_12) {
        for (int bien_13 = bien_12 + 1; bien_13 < bien_11; ++bien_13) {
            if (strcmp(bien_7[bien_13].bien_2, bien_7[bien_12].bien_2) < 0) {
                Student bien_14 = bien_7[bien_12];
                bien_7[bien_12] = bien_7[bien_13];
                bien_7[bien_13] = bien_14;
            }
        }
    }

    for (int bien_12 = 0; bien_12 < bien_11; ++bien_12) {
        printf("%d %s %s %s %.1f %.1f %.1f\n",
               bien_12 + 1, bien_7[bien_12].bien_1, bien_7[bien_12].bien_2, bien_7[bien_12].bien_3, bien_7[bien_12].bien_4, bien_7[bien_12].bien_5, bien_7[bien_12].bien_6);
    }

    return 0;
}
