#include <stdio.h>
#include <string.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);
    while (bien_1--) {
        char bien_2[32];
        scanf("%s", bien_2);
        int bien_3 = (int)strlen(bien_2);

        int bien_4 = 0, bien_5 = 0;
        for (int bien_6 = 0; bien_6 < bien_3; ++bien_6) {
            int bien_7 = bien_2[bien_6] - '0';
            if (bien_7 % 2 == 0) bien_4++;
            else bien_5++;
        }

        int bien_8 = bien_2[bien_3 - 1] - '0';
        if (bien_8 % 2 == 0 && bien_4 > bien_5) printf("YES\n");
        else printf("NO\n");
    }
    return 0;
}
