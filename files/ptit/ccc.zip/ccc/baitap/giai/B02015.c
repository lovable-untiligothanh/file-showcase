#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int ham_1(int bien_1) {
    return bien_1 < 0 ? -bien_1 : bien_1;
}

int main() {
    int bien_2;
    scanf("%d", &bien_2);
    while (bien_2--) {
        char bien_3[32];
        scanf("%s", bien_3);
        int bien_4 = (int)strlen(bien_3);

        int bien_5 = 0, bien_6 = 1;
        for (int bien_7 = 0; bien_7 < bien_4; ++bien_7) {
            int bien_8 = bien_3[bien_7] - '0';
            bien_5 += bien_8;
            if (bien_7 > 0) {
                int bien_9 = bien_3[bien_7 - 1] - '0';
                if (ham_1(bien_8 - bien_9) != 2) bien_6 = 0;
            }
        }

        if (bien_6 && bien_5 % 10 == 0) printf("YES\n");
        else printf("NO\n");
    }
    return 0;
}
