#include <stdio.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);

    while (bien_1--) {
        long long bien_2;
        scanf("%lld", &bien_2);

        long long bien_3 = 0;
        for (long long bien_4 = 2; bien_4 * (bien_4 + 1) / 2 <= bien_2; ++bien_4) {
            long long bien_5 = bien_2 - bien_4 * (bien_4 - 1) / 2;
            if (bien_5 > 0 && bien_5 % bien_4 == 0) bien_3++;
        }

        printf("%lld\n", bien_3);
    }

    return 0;
}
