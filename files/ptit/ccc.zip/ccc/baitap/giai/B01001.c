#include <stdio.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);

    while (bien_1--) {
        long long bien_2;
        scanf("%lld", &bien_2);

        printf("%.15f\n", 1.0 / bien_2);
    }

    return 0;
}
