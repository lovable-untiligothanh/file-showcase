#include <stdio.h>

int main() {
    long long bien_1, bien_2;
    scanf("%lld %lld", &bien_1, &bien_2);

    printf("%lld\n", bien_1 + bien_2);
    printf("%lld\n", bien_1 - bien_2);
    printf("%lld\n", bien_1 * bien_2);
    printf("%lld\n", bien_1 / bien_2);
    printf("%lld\n", bien_1 % bien_2);

    printf("%.2f", (double)bien_1 / (double)bien_2);

    return 0;
}
