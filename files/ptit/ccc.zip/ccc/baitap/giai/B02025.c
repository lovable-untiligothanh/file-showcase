#include <stdio.h>

#define MOD 1000000007LL

long long ham_1(long long bien_1, long long bien_2) {
    long long bien_3 = 1;
    bien_1 %= MOD;
    while (bien_2 > 0) {
        if (bien_2 & 1LL) bien_3 = (bien_3 * bien_1) % MOD;
        bien_1 = (bien_1 * bien_1) % MOD;
        bien_2 >>= 1LL;
    }
    return bien_3;
}

int main() {
    int bien_4;
    scanf("%d", &bien_4);
    while (bien_4--) {
        long long bien_5, bien_6;
        scanf("%lld%lld", &bien_5, &bien_6);

        long long bien_7 = 0;
        int bien_8 = 0;
        while (bien_6 > 0) {
            if (bien_6 & 1LL) {
                bien_7 = (bien_7 + ham_1(bien_5, bien_8)) % MOD;
            }
            bien_8++;
            bien_6 >>= 1LL;
        }

        printf("%lld\n", bien_7);
    }
    return 0;
}
