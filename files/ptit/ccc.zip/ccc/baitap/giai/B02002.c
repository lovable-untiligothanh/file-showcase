#include <stdio.h>
#include <string.h>

#define LIMIT 1300000

int main() {
    int bien_1;
    scanf("%d", &bien_1);

    static unsigned char bien_2[LIMIT + 1];
    int bien_3 = 0;

    for (int bien_4 = 2; bien_4 <= LIMIT && bien_3 < bien_1; ++bien_4) {
        if (!bien_2[bien_4]) {
            printf("%d\n", bien_4);
            bien_3++;
            if ((long long)bien_4 * bien_4 <= LIMIT) {
                for (int bien_5 = bien_4 * bien_4; bien_5 <= LIMIT; bien_5 += bien_4) bien_2[bien_5] = 1;
            }
        }
    }

    return 0;
}
