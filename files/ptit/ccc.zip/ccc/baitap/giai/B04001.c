#include <stdio.h>
#include <string.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);
    while (bien_1--) {
        char bien_2[510];
        scanf("%s", bien_2);
        int bien_3 = (int)strlen(bien_2);
        if (bien_3 >= 2 && bien_2[bien_3 - 2] == '8' && bien_2[bien_3 - 1] == '6') printf("YES\n");
        else printf("NO\n");
    }
    return 0;
}
