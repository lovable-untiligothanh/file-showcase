#include <stdio.h>

int ham_1(int bien_1, int bien_2) {
    while (bien_2 != 0) {
        int bien_3 = bien_1 % bien_2;
        bien_1 = bien_2;
        bien_2 = bien_3;
    }
    return bien_1;
}

int ham_2(int bien_4) {
    int bien_5 = 1;
    while (bien_4--) bien_5 *= 10;
    return bien_5;
}

int main() {
    int bien_6, bien_4;
    scanf("%d%d", &bien_6, &bien_4);

    int bien_7 = ham_2(bien_4 - 1);
    int bien_3 = ham_2(bien_4) - 1;

    int bien_8 = 0;
    for (int bien_9 = bien_7; bien_9 <= bien_3; ++bien_9) {
        if (ham_1(bien_9, bien_6) == 1) {
            if (bien_8 > 0 && bien_8 % 10 == 0) printf("\n");
            else if (bien_8 > 0) printf(" ");
            printf("%d", bien_9);
            bien_8++;
        }
    }
    if (bien_8 > 0) printf("\n");

    return 0;
}
