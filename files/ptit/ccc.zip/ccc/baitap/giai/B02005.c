#include <stdio.h>

int ham_1(int bien_1) {
    if (bien_1 < 2) return 0;
    if (bien_1 % 2 == 0) return bien_1 == 2;
    for (int bien_2 = 3; bien_2 * bien_2 <= bien_1; bien_2 += 2) {
        if (bien_1 % bien_2 == 0) return 0;
    }
    return 1;
}

int ham_2(int bien_3) {
    int bien_4 = 0, bien_5 = 1;
    while (bien_4 < bien_3) {
        int bien_6 = bien_4 + bien_5;
        bien_4 = bien_5;
        bien_5 = bien_6;
    }
    return bien_4 == bien_3;
}

int ham_3(int bien_1) {
    int bien_3 = 0;
    while (bien_1 > 0) {
        bien_3 += bien_1 % 10;
        bien_1 /= 10;
    }
    return bien_3;
}

int main() {
    int bien_4, bien_5;
    scanf("%d%d", &bien_4, &bien_5);
    if (bien_4 > bien_5) {
        int bien_7 = bien_4;
        bien_4 = bien_5;
        bien_5 = bien_7;
    }

    int bien_8 = 1;
    for (int bien_9 = bien_4; bien_9 <= bien_5; ++bien_9) {
        if (ham_1(bien_9) && ham_2(ham_3(bien_9))) {
            if (!bien_8) printf(" ");
            printf("%d", bien_9);
            bien_8 = 0;
        }
    }
    return 0;
}
