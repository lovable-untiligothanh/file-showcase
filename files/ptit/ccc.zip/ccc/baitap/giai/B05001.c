#include <stdio.h>
#include <string.h>

typedef struct {
    int bien_1;
    char bien_2[105];
    char bien_3[105];
    double bien_4, bien_5, bien_6;
} Item;

int main() {
    int bien_11;
    scanf("%d", &bien_11);
    getchar();

    Item bien_7[105];
    for (int bien_12 = 0; bien_12 < bien_11; ++bien_12) {
        bien_7[bien_12].bien_1 = bien_12 + 1;
        fgets(bien_7[bien_12].bien_2, sizeof(bien_7[bien_12].bien_2), stdin);
        fgets(bien_7[bien_12].bien_3, sizeof(bien_7[bien_12].bien_3), stdin);
        bien_7[bien_12].bien_2[strcspn(bien_7[bien_12].bien_2, "\n")] = '\0';
        bien_7[bien_12].bien_3[strcspn(bien_7[bien_12].bien_3, "\n")] = '\0';
        scanf("%lf%lf", &bien_7[bien_12].bien_4, &bien_7[bien_12].bien_5);
        getchar();
        bien_7[bien_12].bien_6 = bien_7[bien_12].bien_5 - bien_7[bien_12].bien_4;
    }

    for (int bien_12 = 0; bien_12 < bien_11 - 1; ++bien_12) {
        for (int bien_13 = bien_12 + 1; bien_13 < bien_11; ++bien_13) {
            int bien_14 = 0;
            if (bien_7[bien_13].bien_6 > bien_7[bien_12].bien_6) bien_14 = 1;
            else if (bien_7[bien_13].bien_6 == bien_7[bien_12].bien_6 && bien_7[bien_13].bien_1 < bien_7[bien_12].bien_1) bien_14 = 1;

            if (bien_14) {
                Item bien_15 = bien_7[bien_12];
                bien_7[bien_12] = bien_7[bien_13];
                bien_7[bien_13] = bien_15;
            }
        }
    }

    for (int bien_12 = 0; bien_12 < bien_11; ++bien_12) {
        printf("%d %s %s %.2f\n", bien_7[bien_12].bien_1, bien_7[bien_12].bien_2, bien_7[bien_12].bien_3, bien_7[bien_12].bien_6);
    }

    return 0;
}
