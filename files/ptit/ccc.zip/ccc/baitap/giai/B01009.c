#include <stdio.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);
    while (bien_1--) {
        long long bien_2;
        scanf("%lld", &bien_2);

        long long bien_3 = 1;
        for (long long bien_4 = 2; bien_4 * bien_4 <= bien_2; ++bien_4) {
            if (bien_2 % bien_4 == 0) {
                bien_3 *= bien_4;
                while (bien_2 % bien_4 == 0) bien_2 /= bien_4;
            }
        }
        if (bien_2 > 1) bien_3 *= bien_2;

        printf("%lld\n", bien_3);
    }
    return 0;
}
