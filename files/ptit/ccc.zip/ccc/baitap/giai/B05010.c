#include <stdio.h>
#include <string.h>

typedef struct {
    int bien_1;
    char bien_2[10];
    char bien_3[60];
    double bien_4;
    char bien_5[20];
} Student;

int main() {
    int bien_10;
    scanf("%d", &bien_10);
    getchar();

    Student bien_6[55];

    for (int bien_11 = 0; bien_11 < bien_10; ++bien_11) {
        bien_6[bien_11].bien_1 = bien_11 + 1;
        sprintf(bien_6[bien_11].bien_2, "HS%02d", bien_11 + 1);

        fgets(bien_6[bien_11].bien_3, sizeof(bien_6[bien_11].bien_3), stdin);
        bien_6[bien_11].bien_3[strcspn(bien_6[bien_11].bien_3, "\n")] = '\0';

        double bien_12[10];
        for (int bien_13 = 0; bien_13 < 10; ++bien_13) scanf("%lf", &bien_12[bien_13]);
        getchar();

        double bien_14 = 2.0 * bien_12[0] + 2.0 * bien_12[1];
        for (int bien_13 = 2; bien_13 < 10; ++bien_13) bien_14 += bien_12[bien_13];
        bien_6[bien_11].bien_4 = bien_14 / 12.0;

        if (bien_6[bien_11].bien_4 >= 9.0) strcpy(bien_6[bien_11].bien_5, "XUAT SAC");
        else if (bien_6[bien_11].bien_4 >= 8.0) strcpy(bien_6[bien_11].bien_5, "GIOI");
        else if (bien_6[bien_11].bien_4 >= 7.0) strcpy(bien_6[bien_11].bien_5, "KHA");
        else if (bien_6[bien_11].bien_4 >= 5.0) strcpy(bien_6[bien_11].bien_5, "TB");
        else strcpy(bien_6[bien_11].bien_5, "YEU");
    }

    for (int bien_11 = 0; bien_11 < bien_10 - 1; ++bien_11) {
        for (int bien_15 = bien_11 + 1; bien_15 < bien_10; ++bien_15) {
            int bien_16 = 0;
            if (bien_6[bien_15].bien_4 > bien_6[bien_11].bien_4) bien_16 = 1;
            else if (bien_6[bien_15].bien_4 == bien_6[bien_11].bien_4 && bien_6[bien_15].bien_1 < bien_6[bien_11].bien_1) bien_16 = 1;

            if (bien_16) {
                Student bien_17 = bien_6[bien_11];
                bien_6[bien_11] = bien_6[bien_15];
                bien_6[bien_15] = bien_17;
            }
        }
    }

    for (int bien_11 = 0; bien_11 < bien_10; ++bien_11) {
        printf("%s %s %.1f %s\n", bien_6[bien_11].bien_2, bien_6[bien_11].bien_3, bien_6[bien_11].bien_4 + 1e-9, bien_6[bien_11].bien_5);
    }

    return 0;
}
