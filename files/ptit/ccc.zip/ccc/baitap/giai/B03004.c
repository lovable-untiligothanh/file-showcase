#include <stdio.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);
    int bien_2[105];
    for (int bien_3 = 0; bien_3 < bien_1; ++bien_3) scanf("%d", &bien_2[bien_3]);

    int bien_4 = 1;
    for (int bien_3 = 0; bien_3 < bien_1; ++bien_3) {
        if (bien_2[bien_3] % 2 == 0) {
            if (!bien_4) printf(" ");
            printf("%d", bien_2[bien_3]);
            bien_4 = 0;
        }
    }
    printf("\n");

    bien_4 = 1;
    for (int bien_3 = 0; bien_3 < bien_1; ++bien_3) {
        if (bien_2[bien_3] % 2 != 0) {
            if (!bien_4) printf(" ");
            printf("%d", bien_2[bien_3]);
            bien_4 = 0;
        }
    }

    return 0;
}
