#include <stdio.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);
    while (bien_1--) {
        char bien_2[510];
        scanf("%s", bien_2);

        unsigned long long bien_3 = 1;
        for (int bien_4 = 0; bien_2[bien_4]; ++bien_4) {
            int bien_5 = bien_2[bien_4] - '0';
            if (bien_5 != 0) bien_3 *= (unsigned long long)bien_5;
        }

        printf("%llu\n", bien_3);
    }
    return 0;
}
