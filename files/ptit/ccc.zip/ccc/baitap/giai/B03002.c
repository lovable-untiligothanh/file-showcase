#include <stdio.h>

int main() {
    unsigned long long bien_1[93];
    bien_1[1] = 1;
    bien_1[2] = 1;
    for (int bien_2 = 3; bien_2 <= 92; ++bien_2) bien_1[bien_2] = bien_1[bien_2 - 1] + bien_1[bien_2 - 2];

    int bien_3;
    scanf("%d", &bien_3);
    while (bien_3--) {
        int bien_4;
        scanf("%d", &bien_4);
        printf("%llu\n", bien_1[bien_4]);
    }
    return 0;
}
