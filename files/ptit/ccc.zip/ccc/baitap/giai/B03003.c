#include <stdio.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);
    while (bien_1--) {
        int bien_2;
        scanf("%d", &bien_2);
        int bien_3[105];
        for (int bien_4 = 0; bien_4 < bien_2; ++bien_4) scanf("%d", &bien_3[bien_4]);

        int bien_5 = bien_3[0];
        for (int bien_4 = 1; bien_4 < bien_2; ++bien_4) if (bien_3[bien_4] > bien_5) bien_5 = bien_3[bien_4];

        printf("%d\n", bien_5);
        int bien_6 = 1;
        for (int bien_4 = 0; bien_4 < bien_2; ++bien_4) {
            if (bien_3[bien_4] == bien_5) {
                if (!bien_6) printf(" ");
                printf("%d", bien_4);
                bien_6 = 0;
            }
        }
        printf("\n");
    }
    return 0;
}
