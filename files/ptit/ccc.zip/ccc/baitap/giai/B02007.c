#include <stdio.h>

long long C(int bien_1, int bien_2) {
    if (bien_2 == 0 || bien_2 == bien_1) return 1;
    return C(bien_1 - 1, bien_2 - 1) + C(bien_1 - 1, bien_2);
}

int main() {
    int bien_1;
    scanf("%d", &bien_1);

    for (int bien_3 = 0; bien_3 < bien_1; ++bien_3) {
        for (int bien_4 = 0; bien_4 <= bien_3; ++bien_4) {
            if (bien_4) printf(" ");
            printf("%lld", C(bien_3, bien_4));
        }
        printf("\n");
    }

    return 0;
}
