#include <stdio.h>

int main() {
    int bien_1, bien_2;
    scanf("%d%d", &bien_1, &bien_2);

    long long A[55][55], C[55][55];
    long long bien_3 = 0;

    for (int bien_4 = 0; bien_4 < bien_1; ++bien_4) {
        for (int bien_5 = 0; bien_5 < bien_2; ++bien_5) {
            scanf("%lld", &A[bien_4][bien_5]);
            bien_3 += A[bien_4][bien_5];
        }
    }

    long long bien_6 = bien_3 / (bien_1 * bien_2);
    for (int bien_4 = 0; bien_4 < bien_1; ++bien_4)
        for (int bien_5 = 0; bien_5 < bien_2; ++bien_5)
            if (A[bien_4][bien_5] > bien_6) A[bien_4][bien_5] = 0;

    for (int bien_4 = 0; bien_4 < bien_1; ++bien_4) {
        for (int bien_5 = 0; bien_5 < bien_1; ++bien_5) {
            C[bien_4][bien_5] = 0;
            for (int bien_7 = 0; bien_7 < bien_2; ++bien_7) C[bien_4][bien_5] += A[bien_4][bien_7] * A[bien_5][bien_7];
        }
    }

    for (int bien_4 = 0; bien_4 < bien_1; ++bien_4) {
        for (int bien_5 = 0; bien_5 < bien_1; ++bien_5) {
            if (bien_5) printf(" ");
            printf("%lld", C[bien_4][bien_5]);
        }
        printf("\n");
    }

    return 0;
}
