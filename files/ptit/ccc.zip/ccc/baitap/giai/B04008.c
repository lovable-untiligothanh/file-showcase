#include <stdio.h>
#include <string.h>

int ham_1(const char bien_1[], const char bien_2[]) {
    int bien_3 = (int)strlen(bien_1), bien_4 = (int)strlen(bien_2);
    if (bien_3 != bien_4) return (bien_3 > bien_4) ? 1 : -1;
    return strcmp(bien_1, bien_2) > 0 ? 1 : (strcmp(bien_1, bien_2) < 0 ? -1 : 0);
}

void ham_2(const char bien_1[], const char bien_2[], char bien_5[]) {
    int bien_3 = (int)strlen(bien_1), bien_4 = (int)strlen(bien_2);
    int bien_6 = bien_3 - 1, bien_7 = bien_4 - 1, bien_8 = 0, bien_9 = 0;
    char bien_10[2205];

    while (bien_6 >= 0) {
        int bien_11 = bien_1[bien_6] - '0' - bien_9;
        int bien_12 = (bien_7 >= 0) ? bien_2[bien_7] - '0' : 0;
        if (bien_11 < bien_12) {
            bien_11 += 10;
            bien_9 = 1;
        } else {
            bien_9 = 0;
        }
        bien_10[bien_8++] = (char)('0' + (bien_11 - bien_12));
        bien_6--;
        bien_7--;
    }

    while (bien_8 > 1 && bien_10[bien_8 - 1] == '0') bien_8--;
    for (int bien_13 = 0; bien_13 < bien_8; ++bien_13) bien_5[bien_13] = bien_10[bien_8 - 1 - bien_13];
    bien_5[bien_8] = '\0';
}

int main() {
    int bien_14;
    scanf("%d", &bien_14);
    while (bien_14--) {
        char bien_1[2205], bien_2[2205], bien_15[2205];
        scanf("%s%s", bien_1, bien_2);

        if (ham_1(bien_1, bien_2) >= 0) ham_2(bien_1, bien_2, bien_15);
        else ham_2(bien_2, bien_1, bien_15);

        printf("%s\n", bien_15);
    }
    return 0;
}
