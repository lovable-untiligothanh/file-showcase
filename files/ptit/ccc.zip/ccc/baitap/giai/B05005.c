#include <stdio.h>
#include <string.h>

typedef struct {
    int bien_1;
    char bien_2[10];
    char bien_3[60];
    long long bien_4;
} Customer;

int main() {
    int bien_9;
    scanf("%d", &bien_9);
    getchar();

    Customer bien_5[25];

    for (int bien_10 = 0; bien_10 < bien_9; ++bien_10) {
        bien_5[bien_10].bien_1 = bien_10 + 1;
        sprintf(bien_5[bien_10].bien_2, "KH%02d", bien_10 + 1);

        fgets(bien_5[bien_10].bien_3, sizeof(bien_5[bien_10].bien_3), stdin);
        bien_5[bien_10].bien_3[strcspn(bien_5[bien_10].bien_3, "\n")] = '\0';

        int bien_11, bien_12;
        scanf("%d%d", &bien_11, &bien_12);
        getchar();

        int bien_13 = bien_12 - bien_11;
        long long bien_14;
        int bien_15;

        if (bien_13 <= 50) {
            bien_14 = 100LL * bien_13;
            bien_15 = 2;
        } else if (bien_13 <= 100) {
            bien_14 = 50LL * 100 + 150LL * (bien_13 - 50);
            bien_15 = 3;
        } else {
            bien_14 = 50LL * 100 + 50LL * 150 + 200LL * (bien_13 - 100);
            bien_15 = 5;
        }

        bien_5[bien_10].bien_4 = bien_14 + (bien_14 * bien_15 + 99) / 100;
    }

    for (int bien_10 = 0; bien_10 < bien_9 - 1; ++bien_10) {
        for (int bien_11 = bien_10 + 1; bien_11 < bien_9; ++bien_11) {
            int bien_12 = 0;
            if (bien_5[bien_11].bien_4 > bien_5[bien_10].bien_4) bien_12 = 1;
            else if (bien_5[bien_11].bien_4 == bien_5[bien_10].bien_4 && bien_5[bien_11].bien_1 < bien_5[bien_10].bien_1) bien_12 = 1;

            if (bien_12) {
                Customer bien_13 = bien_5[bien_10];
                bien_5[bien_10] = bien_5[bien_11];
                bien_5[bien_11] = bien_13;
            }
        }
    }

    for (int bien_10 = 0; bien_10 < bien_9; ++bien_10) {
        printf("%s %s %lld\n", bien_5[bien_10].bien_2, bien_5[bien_10].bien_3, bien_5[bien_10].bien_4);
    }

    return 0;
}
