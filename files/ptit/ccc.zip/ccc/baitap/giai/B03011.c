#include <stdio.h>

void ham_1(int bien_1[], int bien_2) {
    for (int bien_3 = 0; bien_3 < bien_2; ++bien_3) {
        if (bien_3) printf(" ");
        printf("%d", bien_1[bien_3]);
    }
    printf("\n");
}

int main() {
    int bien_2;
    scanf("%d", &bien_2);
    int bien_1[105];
    for (int bien_3 = 0; bien_3 < bien_2; ++bien_3) scanf("%d", &bien_1[bien_3]);

    int bien_4 = 1;
    for (int bien_3 = 0; bien_3 < bien_2 - 1; ++bien_3) {
        int bien_5 = 0;
        for (int bien_6 = 0; bien_6 < bien_2 - 1 - bien_3; ++bien_6) {
            if (bien_1[bien_6] > bien_1[bien_6 + 1]) {
                int bien_7 = bien_1[bien_6];
                bien_1[bien_6] = bien_1[bien_6 + 1];
                bien_1[bien_6 + 1] = bien_7;
                bien_5 = 1;
            }
        }
        if (bien_5) {
            printf("Buoc %d: ", bien_4++);
            ham_1(bien_1, bien_2);
        } else {
            break;
        }
    }

    return 0;
}
