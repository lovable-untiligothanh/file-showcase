#include <stdio.h>

int ham_1(int bien_1) {
    if (bien_1 < 2) return 0;
    if (bien_1 % 2 == 0) return bien_1 == 2;
    for (int bien_2 = 3; bien_2 * bien_2 <= bien_1; bien_2 += 2) {
        if (bien_1 % bien_2 == 0) return 0;
    }
    return 1;
}

int main() {
    int bien_3;
    scanf("%d", &bien_3);
    while (bien_3--) {
        int bien_1;
        scanf("%d", &bien_1);

        int bien_4[1001] = {0};
        for (int bien_2 = 0; bien_2 < bien_1; ++bien_2) {
            int bien_5;
            scanf("%d", &bien_5);
            if (bien_5 >= 0 && bien_5 <= 1000) bien_4[bien_5] = 1;
        }

        int bien_6 = 1;
        for (int bien_5 = 2; bien_5 <= 1000; ++bien_5) {
            if (bien_4[bien_5] && ham_1(bien_5)) {
                if (!bien_6) printf(" ");
                printf("%d", bien_5);
                bien_6 = 0;
            }
        }
        printf("\n");
    }
    return 0;
}
