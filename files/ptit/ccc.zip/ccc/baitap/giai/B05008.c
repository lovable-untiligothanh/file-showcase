#include <stdio.h>
#include <string.h>

typedef struct {
    int bien_1;
    char bien_2[60];
    char bien_3[30];
    char bien_4[30];
    int bien_5;
} Racer;

void ham_1(const char bien_3[], const char bien_2[], char bien_6[]) {
    int bien_7 = 0;
    if (bien_3[0] != '\0') bien_6[bien_7++] = bien_3[0];
    for (int bien_8 = 1; bien_3[bien_8]; ++bien_8) if (bien_3[bien_8 - 1] == ' ' && bien_3[bien_8] != ' ') bien_6[bien_7++] = bien_3[bien_8];

    if (bien_2[0] != '\0') bien_6[bien_7++] = bien_2[0];
    for (int bien_8 = 1; bien_2[bien_8]; ++bien_8) if (bien_2[bien_8 - 1] == ' ' && bien_2[bien_8] != ' ') bien_6[bien_7++] = bien_2[bien_8];

    bien_6[bien_7] = '\0';
}

int main() {
    int bien_13;
    scanf("%d", &bien_13);
    getchar();

    Racer bien_9[105];
    for (int bien_8 = 0; bien_8 < bien_13; ++bien_8) {
        bien_9[bien_8].bien_1 = bien_8 + 1;

        fgets(bien_9[bien_8].bien_2, sizeof(bien_9[bien_8].bien_2), stdin);
        fgets(bien_9[bien_8].bien_3, sizeof(bien_9[bien_8].bien_3), stdin);
        bien_9[bien_8].bien_2[strcspn(bien_9[bien_8].bien_2, "\n")] = '\0';
        bien_9[bien_8].bien_3[strcspn(bien_9[bien_8].bien_3, "\n")] = '\0';

        char bien_14[10];
        fgets(bien_14, sizeof(bien_14), stdin);
        bien_14[strcspn(bien_14, "\n")] = '\0';

        int bien_15, bien_16;
        sscanf(bien_14, "%d:%d", &bien_15, &bien_16);
        int bien_17 = (bien_15 - 6) * 60 + bien_16;

        double bien_18 = 120.0 * 60.0 / bien_17;
        bien_9[bien_8].bien_5 = (int)(bien_18 + 0.5);

        ham_1(bien_9[bien_8].bien_3, bien_9[bien_8].bien_2, bien_9[bien_8].bien_4);
    }

    for (int bien_8 = 0; bien_8 < bien_13 - 1; ++bien_8) {
        for (int bien_19 = bien_8 + 1; bien_19 < bien_13; ++bien_19) {
            int bien_20 = 0;
            if (bien_9[bien_19].bien_5 > bien_9[bien_8].bien_5) bien_20 = 1;
            else if (bien_9[bien_19].bien_5 == bien_9[bien_8].bien_5 && bien_9[bien_19].bien_1 < bien_9[bien_8].bien_1) bien_20 = 1;

            if (bien_20) {
                Racer bien_21 = bien_9[bien_8];
                bien_9[bien_8] = bien_9[bien_19];
                bien_9[bien_19] = bien_21;
            }
        }
    }

    for (int bien_8 = 0; bien_8 < bien_13; ++bien_8) {
        printf("%s %s %s %d Km/h\n", bien_9[bien_8].bien_4, bien_9[bien_8].bien_2, bien_9[bien_8].bien_3, bien_9[bien_8].bien_5);
    }

    return 0;
}
