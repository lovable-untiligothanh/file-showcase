#include <stdio.h>
#include <string.h>

typedef struct {
    int bien_1;
    char bien_2[105];
    char bien_3[25];
    double bien_4;
} Candidate;

int main() {
    int bien_9;
    scanf("%d", &bien_9);
    getchar();

    Candidate bien_5[105];

    for (int bien_10 = 0; bien_10 < bien_9; ++bien_10) {
        bien_5[bien_10].bien_1 = bien_10 + 1;
        fgets(bien_5[bien_10].bien_2, sizeof(bien_5[bien_10].bien_2), stdin);
        fgets(bien_5[bien_10].bien_3, sizeof(bien_5[bien_10].bien_3), stdin);
        bien_5[bien_10].bien_2[strcspn(bien_5[bien_10].bien_2, "\n")] = '\0';
        bien_5[bien_10].bien_3[strcspn(bien_5[bien_10].bien_3, "\n")] = '\0';

        double bien_11, bien_12, bien_13;
        scanf("%lf%lf%lf", &bien_11, &bien_12, &bien_13);
        getchar();
        bien_5[bien_10].bien_4 = bien_11 + bien_12 + bien_13;
    }

    for (int bien_10 = 0; bien_10 < bien_9 - 1; ++bien_10) {
        for (int bien_11 = bien_10 + 1; bien_11 < bien_9; ++bien_11) {
            int bien_12 = 0;
            if (bien_5[bien_11].bien_4 > bien_5[bien_10].bien_4) bien_12 = 1;
            else if (bien_5[bien_11].bien_4 == bien_5[bien_10].bien_4 && bien_5[bien_11].bien_1 < bien_5[bien_10].bien_1) bien_12 = 1;

            if (bien_12) {
                Candidate bien_13 = bien_5[bien_10];
                bien_5[bien_10] = bien_5[bien_11];
                bien_5[bien_11] = bien_13;
            }
        }
    }

    for (int bien_10 = 0; bien_10 < bien_9; ++bien_10) {
        printf("%d %s %s %.1f\n", bien_5[bien_10].bien_1, bien_5[bien_10].bien_2, bien_5[bien_10].bien_3, bien_5[bien_10].bien_4);
    }

    return 0;
}
