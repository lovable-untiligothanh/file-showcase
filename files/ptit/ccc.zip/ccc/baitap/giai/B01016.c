#include <stdio.h>

int main() {
    long long bien_1;
    while (scanf("%lld", &bien_1) == 1 && bien_1 != 0) {
        int bien_2 = 1;
        while (bien_1 != 1) {
            if (bien_1 % 2 == 0) bien_1 /= 2;
            else bien_1 = bien_1 * 3 + 1;
            bien_2++;
        }
        printf("%d\n", bien_2);
    }
    return 0;
}
