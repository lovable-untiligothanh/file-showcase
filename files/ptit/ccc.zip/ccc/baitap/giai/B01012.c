#include <stdio.h>

int main() {
    int bien_1, bien_2;
    if (scanf("%d%d", &bien_1, &bien_2) != 2) return 0;

    for (int bien_3 = 0; bien_3 < bien_2; ++bien_3) {
        for (int bien_4 = 0; bien_4 < bien_1; ++bien_4) {
            if (bien_3 == 0 || bien_3 == bien_2 - 1 || bien_4 == 0 || bien_4 == bien_1 - 1) printf("*");
            else printf(" ");
        }
        printf("\n");
    }

    return 0;
}
