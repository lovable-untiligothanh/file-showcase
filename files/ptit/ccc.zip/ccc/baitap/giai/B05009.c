#include <stdio.h>

typedef struct {
    int bien_1, bien_2, bien_3;
} TimeVal;

int main() {
    int bien_8;
    scanf("%d", &bien_8);
    TimeVal bien_4[5005];
    for (int bien_9 = 0; bien_9 < bien_8; ++bien_9) scanf("%d%d%d", &bien_4[bien_9].bien_1, &bien_4[bien_9].bien_2, &bien_4[bien_9].bien_3);

    for (int bien_9 = 0; bien_9 < bien_8 - 1; ++bien_9) {
        for (int bien_10 = bien_9 + 1; bien_10 < bien_8; ++bien_10) {
            int bien_11 = 0;
            if (bien_4[bien_10].bien_1 < bien_4[bien_9].bien_1) bien_11 = 1;
            else if (bien_4[bien_10].bien_1 == bien_4[bien_9].bien_1 && bien_4[bien_10].bien_2 < bien_4[bien_9].bien_2) bien_11 = 1;
            else if (bien_4[bien_10].bien_1 == bien_4[bien_9].bien_1 && bien_4[bien_10].bien_2 == bien_4[bien_9].bien_2 && bien_4[bien_10].bien_3 < bien_4[bien_9].bien_3) bien_11 = 1;

            if (bien_11) {
                TimeVal bien_12 = bien_4[bien_9];
                bien_4[bien_9] = bien_4[bien_10];
                bien_4[bien_10] = bien_12;
            }
        }
    }

    for (int bien_9 = 0; bien_9 < bien_8; ++bien_9) printf("%d %d %d\n", bien_4[bien_9].bien_1, bien_4[bien_9].bien_2, bien_4[bien_9].bien_3);

    return 0;
}
