#include <stdio.h>
#include <string.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);
    while (bien_1--) {
        char bien_2[32];
        scanf("%s", bien_2);
        int bien_3 = (int)strlen(bien_2);

        int bien_4 = 1;
        for (int bien_5 = 2; bien_5 < bien_3; ++bien_5) {
            if (bien_2[bien_5] != bien_2[bien_5 - 2]) {
                bien_4 = 0;
                break;
            }
        }

        int bien_6[10] = {0};
        int bien_7 = 0;
        for (int bien_5 = 0; bien_5 < bien_3; ++bien_5) {
            int bien_8 = bien_2[bien_5] - '0';
            if (!bien_6[bien_8]) {
                bien_6[bien_8] = 1;
                bien_7++;
            }
        }

        if (bien_7 != 2) bien_4 = 0;
        printf(bien_4 ? "YES\n" : "NO\n");
    }
    return 0;
}
