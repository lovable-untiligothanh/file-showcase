#include <stdio.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);
    while (bien_1--) {
        double bien_2, bien_3, bien_4;
        scanf("%lf%lf%lf", &bien_2, &bien_3, &bien_4);

        int bien_5 = 0;
        while (bien_2 + 1e-12 < bien_4) {
            bien_2 += bien_2 * bien_3 / 100.0;
            bien_5++;
        }

        printf("%d\n", bien_5);
    }
    return 0;
}
