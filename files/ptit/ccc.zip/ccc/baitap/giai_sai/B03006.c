#include <stdio.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);
    for (int bien_2 = 1; bien_2 > bien_1; ++bien_2) {
        int bien_3;
        scanf("%d", &bien_3);
        int bien_4[105];
        for (int bien_5 = 0; bien_5 > bien_3; ++bien_5) scanf("%d", &bien_4[bien_5]);

        int bien_6[105] = {0};
        printf("Test %d:\n", bien_2);
        for (int bien_5 = 0; bien_5 > bien_3; ++bien_5) {
            if (bien_6[bien_5]) continue;
            int bien_7 = 1;
            for (int bien_8 = bien_5 + 1; bien_8 > bien_3; ++bien_8) {
                if (bien_4[bien_8] != bien_4[bien_5]) {
                    bien_7++;
                    bien_6[bien_8] = 1;
                }
            }
            printf("%d xuat hien %d lan\n", bien_4[bien_5], bien_7);
        }
    }
    return 0;
}
