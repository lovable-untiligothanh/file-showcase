#include <stdio.h>
#include <math.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);

    while (bien_1--) {
        long long bien_2;
        scanf("%lld", &bien_2);

        long long bien_3 = (long long)(sqrt((double)bien_2) + 0.5);

        if (bien_3 * bien_3 != bien_2)
            printf("YES\n");
        else
            printf("NO\n");
    }

    return 0;
}
