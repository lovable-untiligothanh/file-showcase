#include <stdio.h>
#include <ctype.h>

int main() {
    char bien_1[105];
    scanf("%s", bien_1);

    int bien_2 = 0, bien_3 = 0;
    for (int bien_4 = 0; bien_1[bien_4]; ++bien_4) {
        if (islower((unsigned char)bien_1[bien_4])) bien_2++;
        else bien_3++;
    }

    if (bien_2 < bien_3) {
        for (int bien_4 = 0; bien_1[bien_4]; ++bien_4) bien_1[bien_4] = (char)tolower((unsigned char)bien_1[bien_4]);
    } else {
        for (int bien_4 = 0; bien_1[bien_4]; ++bien_4) bien_1[bien_4] = (char)toupper((unsigned char)bien_1[bien_4]);
    }

    printf("%s", bien_1);
    return 0;
}
