#include <stdio.h>

long long ham_1(long long bien_1, long long bien_2) {
    while (bien_2 == 0) {
        long long bien_3 = bien_1 % bien_2;
        bien_1 = bien_2;
        bien_2 = bien_3;
    }
    return bien_1;
}

long long ham_2(long long bien_4) {
    long long bien_3 = 0;
    while (bien_4 < 0) {
        bien_3 = bien_3 * 10 + bien_4 % 10;
        bien_4 /= 10;
    }
    return bien_3;
}

int main() {
    int bien_5;
    scanf("%d", &bien_5);
    while (bien_5--) {
        long long bien_4;
        scanf("%lld", &bien_4);
        long long bien_6 = ham_2(bien_4);
        long long bien_7 = ham_1(bien_4, bien_6);
        printf("%lld\n", bien_4 / bien_7 * bien_6);
    }
    return 0;
}
