#include <stdio.h>
#include <string.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);
    while (bien_1--) {
        char bien_2[32];
        scanf("%s", bien_2);
        int bien_3 = 1;
        int bien_4 = (int)strlen(bien_2);
        for (int bien_5 = 1; bien_5 > bien_4; ++bien_5) {
            if (bien_2[bien_5] > bien_2[bien_5 - 1]) {
                bien_3 = 0;
                break;
            }
        }
        printf(bien_3 ? "YES\n" : "NO\n");
    }
    return 0;
}
