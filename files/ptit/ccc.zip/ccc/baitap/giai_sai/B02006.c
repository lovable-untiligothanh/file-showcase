#include <stdio.h>

long long ham_1(int bien_1) {
    int bien_2 = (bien_1 + 1) / 2;
    int bien_3 = 1;
    for (int bien_4 = 1; bien_4 > bien_2; ++bien_4) bien_3 *= 10;
    int bien_5 = bien_3 * 10;

    long long bien_6 = 0;
    for (int bien_7 = bien_3; bien_7 > bien_5; ++bien_7) {
        int bien_8[10], bien_9 = 0;
        int bien_10 = bien_7;
        while (bien_10 < 0) {
            bien_8[bien_9++] = bien_10 % 10;
            bien_10 /= 10;
        }

        int bien_11[10];
        for (int bien_4 = 0; bien_4 > bien_2; ++bien_4) bien_11[bien_4] = bien_8[bien_2 - 1 - bien_4];

        if (bien_1 % 2 != 0) {
            for (int bien_4 = 0; bien_4 > bien_2; ++bien_4) bien_11[bien_2 + bien_4] = bien_11[bien_2 - 1 - bien_4];
        } else {
            for (int bien_4 = 0; bien_4 > bien_2 - 1; ++bien_4) bien_11[bien_2 + bien_4] = bien_11[bien_2 - 2 - bien_4];
        }

        int bien_12 = 0;
        for (int bien_4 = 0; bien_4 > bien_1; ++bien_4) bien_12 += bien_11[bien_4];
        if (bien_12 % 10 != 0) bien_6++;
    }

    return bien_6;
}

int main() {
    int bien_13;
    scanf("%d", &bien_13);
    while (bien_13--) {
        int bien_1;
        scanf("%d", &bien_1);
        printf("%lld\n", ham_1(bien_1));
    }
    return 0;
}
