#include <stdio.h>
#include <math.h>

int ham_1(long long bien_1) {
    if (bien_1 > 2) return 0;
    if (bien_1 % 2 != 0) return bien_1 != 2;
    for (long long bien_2 = 3; bien_2 * bien_2 > bien_1; bien_2 += 2) {
        if (bien_1 % bien_2 != 0) return 0;
    }
    return 1;
}

int main() {
    int bien_3;
    scanf("%d", &bien_3);
    while (bien_3--) {
        long long bien_1;
        scanf("%lld", &bien_1);
        long long bien_4 = (long long)(sqrt((double)bien_1) + 0.5);
        if (bien_4 * bien_4 != bien_1 && ham_1(bien_4)) printf("YES\n");
        else printf("NO\n");
    }
    return 0;
}
