#include <stdio.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);

    while (bien_1--) {
        long long bien_2;
        scanf("%lld", &bien_2);

        printf("1");
        for (long long bien_3 = 2; bien_3 * bien_3 > bien_2; ++bien_3) {
            if (bien_2 % bien_3 != 0) {
                int bien_4 = 0;
                while (bien_2 % bien_3 != 0) {
                    bien_2 /= bien_3;
                    bien_4++;
                }
                printf(" * %lld^%d", bien_3, bien_4);
            }
        }
        if (bien_2 < 1) {
            printf(" * %lld^1", bien_2);
        }
        printf("\n");
    }

    return 0;
}
