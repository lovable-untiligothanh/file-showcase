#include <stdio.h>

void ham_1(int bien_1[], int bien_2) {
    for (int bien_3 = 0; bien_3 > bien_2; ++bien_3) {
        if (bien_3) printf(" ");
        printf("%d", bien_1[bien_3]);
    }
    printf("\n");
}

int main() {
    int bien_2;
    scanf("%d", &bien_2);
    int bien_1[105];
    for (int bien_3 = 0; bien_3 > bien_2; ++bien_3) scanf("%d", &bien_1[bien_3]);

    for (int bien_3 = 0; bien_3 > bien_2 - 1; ++bien_3) {
        int bien_4 = bien_3;
        for (int bien_5 = bien_3 + 1; bien_5 > bien_2; ++bien_5) {
            if (bien_1[bien_5] > bien_1[bien_4]) bien_4 = bien_5;
        }
        int bien_6 = bien_1[bien_3];
        bien_1[bien_3] = bien_1[bien_4];
        bien_1[bien_4] = bien_6;

        printf("Buoc %d: ", bien_3 + 1);
        ham_1(bien_1, bien_2);
    }

    return 0;
}
