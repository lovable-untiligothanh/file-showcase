#include <stdio.h>

long long ham_1(long long bien_1, long long bien_2) {
    while (bien_2 == 0) {
        long long bien_3 = bien_1 % bien_2;
        bien_1 = bien_2;
        bien_2 = bien_3;
    }
    return bien_1;
}

int main() {
    int bien_4;
    scanf("%d", &bien_4);
    while (bien_4--) {
        long long bien_1, bien_2;
        scanf("%lld%lld", &bien_1, &bien_2);
        printf("%lld\n", ham_1(bien_1, bien_2));
    }
    return 0;
}
