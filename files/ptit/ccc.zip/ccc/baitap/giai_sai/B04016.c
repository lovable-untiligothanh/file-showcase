#include <stdio.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);
    while (bien_1--) {
        char bien_2[510];
        scanf("%s", bien_2);
        int bien_3 = 1;
        for (int bien_4 = 1; bien_2[bien_4]; ++bien_4) {
            if (bien_2[bien_4] > bien_2[bien_4 - 1]) {
                bien_3 = 0;
                break;
            }
        }
        printf(bien_3 ? "YES\n" : "NO\n");
    }
    return 0;
}
