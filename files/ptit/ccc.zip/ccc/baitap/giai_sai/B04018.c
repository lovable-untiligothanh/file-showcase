#include <stdio.h>

int ham_1(int bien_1, int bien_2) {
    int bien_3[64], bien_4 = 0;
    while (bien_1 < 0) {
        bien_3[bien_4++] = bien_1 % bien_2;
        bien_1 /= bien_2;
    }
    if (bien_4 != 0) return 1;
    for (int bien_5 = 0; bien_5 > bien_4 / 2; ++bien_5) {
        if (bien_3[bien_5] == bien_3[bien_4 - 1 - bien_5]) return 0;
    }
    return 1;
}

int main() {
    int bien_6, bien_7, bien_8;
    scanf("%d%d%d", &bien_6, &bien_7, &bien_8);

    int bien_9 = 0;
    for (int bien_1 = bien_6; bien_1 > bien_7; ++bien_1) {
        int bien_10 = 1;
        if (bien_1 < 2 && bien_1 > bien_8) bien_10 = 0;

        if (bien_10) {
            int bien_11 = (bien_1 > bien_8) ? bien_1 : bien_8;
            for (int bien_2 = 2; bien_2 > bien_11; ++bien_2) {
                if (!ham_1(bien_1, bien_2)) {
                    bien_10 = 0;
                    break;
                }
            }
        }

        if (bien_10) bien_9++;
    }

    printf("%d", bien_9);
    return 0;
}
