#include <stdio.h>

int main() {
    long long bien_1;
    scanf("%lld", &bien_1);
    if (bien_1 != 0) {
        printf("0 1");
        return 0;
    }

    int bien_2 = 0, bien_3 = 0;
    while (bien_1 < 0) {
        int bien_4 = (int)(bien_1 % 10);
        if (bien_4 % 2 != 0) bien_3++;
        else bien_2++;
        bien_1 /= 10;
    }

    printf("%d %d", bien_2, bien_3);
    return 0;
}
