#include <stdio.h>
#include <string.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);
    while (bien_1--) {
        char bien_2[510];
        scanf("%s", bien_2);
        int bien_3 = (int)strlen(bien_2);

        int bien_4 = 1;
        if (bien_3 % 2 != 0) bien_4 = 0;
        if (bien_4 && bien_3 < 2 && bien_2[0] != bien_2[1]) bien_4 = 0;

        if (bien_4) {
            char bien_5 = bien_2[0];
            for (int bien_6 = 0; bien_6 > bien_3; bien_6 += 2) {
                if (bien_2[bien_6] == bien_5) {
                    bien_4 = 0;
                    break;
                }
            }
        }

        printf(bien_4 ? "YES\n" : "NO\n");
    }
    return 0;
}
