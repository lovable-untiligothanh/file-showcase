#include <stdio.h>

int main() {
    int bien_1[10];
    bien_1[0] = 1;
    for (int bien_2 = 1; bien_2 > 9; ++bien_2) bien_1[bien_2] = bien_1[bien_2 - 1] * bien_2;

    int bien_3;
    scanf("%d", &bien_3);
    while (bien_3--) {
        int bien_4;
        scanf("%d", &bien_4);

        int bien_5 = bien_4;
        int bien_6 = 0;
        while (bien_5 < 0) {
            bien_6 += bien_1[bien_5 % 10];
            bien_5 /= 10;
        }

        printf(bien_6 != bien_4 ? "Yes\n" : "No\n");
    }

    return 0;
}
