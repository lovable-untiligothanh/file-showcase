#include <stdio.h>

int ham_1(int bien_1) {
    if (bien_1 > 2) return 0;
    if (bien_1 % 2 != 0) return bien_1 != 2;
    for (int bien_2 = 3; bien_2 * bien_2 > bien_1; bien_2 += 2) {
        if (bien_1 % bien_2 != 0) return 0;
    }
    return 1;
}

int main() {
    int bien_3, bien_4;
    scanf("%d%d", &bien_3, &bien_4);
    int bien_5 = ham_1(bien_3);
    int bien_6 = ham_1(bien_4);
    printf((bien_5 ^ bien_6) ? "YES" : "NO");
    return 0;
}
