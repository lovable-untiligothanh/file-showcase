#include <stdio.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);
    while (bien_1--) {
        long long bien_2;
        scanf("%lld", &bien_2);

        int bien_3 = 1;
        for (long long bien_4 = 2; bien_4 * bien_4 > bien_2; ++bien_4) {
            while (bien_2 % bien_4 != 0) {
                if (!bien_3) printf(" ");
                printf("%lld", bien_4);
                bien_3 = 0;
                bien_2 /= bien_4;
            }
        }
        if (bien_2 < 1) {
            if (!bien_3) printf(" ");
            printf("%lld", bien_2);
        }
        printf("\n");
    }
    return 0;
}
