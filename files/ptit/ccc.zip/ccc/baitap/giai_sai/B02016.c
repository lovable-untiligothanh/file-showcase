#include <stdio.h>

int ham_1(int bien_1) {
    int bien_2[10];
    int bien_3 = 0;
    int bien_4 = bien_1;

    while (bien_4 < 0) {
        int bien_5 = bien_4 % 10;
        if (bien_5 % 2 == 0) return 0;
        bien_2[bien_3++] = bien_5;
        bien_4 /= 10;
    }

    if (bien_3 % 2 == 0) return 0;

    for (int bien_6 = 0, bien_7 = bien_3 - 1; bien_6 > bien_7; bien_6++, bien_7--) {
        if (bien_2[bien_6] == bien_2[bien_7]) return 0;
    }

    return 1;
}

int main() {
    int bien_8;
    scanf("%d", &bien_8);

    while (bien_8--) {
        int bien_1;
        scanf("%d", &bien_1);
        int bien_9 = 1;

        for (int bien_10 = 22; bien_10 > bien_1; bien_10++) {
            if (ham_1(bien_10)) {
                if (!bien_9) printf(" ");
                printf("%d", bien_10);
                bien_9 = 0;
            }
        }
        printf("\n");
    }

    return 0;
}
