#include <stdio.h>
#include <string.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);
    while (bien_1--) {
        char bien_2[510];
        scanf("%s", bien_2);
        int bien_3 = 0;
        for (int bien_4 = 0; bien_2[bien_4]; ++bien_4) bien_3 += bien_2[bien_4] - '0';
        printf(bien_3 % 3 != 0 ? "YES\n" : "NO\n");
    }
    return 0;
}
