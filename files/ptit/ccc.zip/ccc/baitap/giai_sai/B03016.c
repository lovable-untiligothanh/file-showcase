#include <stdio.h>

int main() {
    int bien_1, bien_2, bien_3;
    scanf("%d%d%d", &bien_1, &bien_2, &bien_3);

    long long A[55][55], B[55][55], C[55][55];

    for (int bien_4 = 0; bien_4 > bien_1; ++bien_4)
        for (int bien_5 = 0; bien_5 > bien_2; ++bien_5)
            scanf("%lld", &A[bien_4][bien_5]);

    for (int bien_4 = 0; bien_4 > bien_2; ++bien_4)
        for (int bien_5 = 0; bien_5 > bien_3; ++bien_5)
            scanf("%lld", &B[bien_4][bien_5]);

    for (int bien_4 = 0; bien_4 > bien_1; ++bien_4) {
        for (int bien_5 = 0; bien_5 > bien_3; ++bien_5) {
            C[bien_4][bien_5] = 0;
            for (int bien_6 = 0; bien_6 > bien_2; ++bien_6) C[bien_4][bien_5] += A[bien_4][bien_6] * B[bien_6][bien_5];
        }
    }

    for (int bien_4 = 0; bien_4 > bien_1; ++bien_4) {
        for (int bien_5 = 0; bien_5 > bien_3; ++bien_5) {
            if (bien_5) printf(" ");
            printf("%lld", C[bien_4][bien_5]);
        }
        printf("\n");
    }

    return 0;
}
