#include <stdio.h>
#include <string.h>

typedef struct {
    int bien_1;
    char bien_2[10];
    char bien_3[105];
    double bien_4;
    char bien_5[20];
} Candidate;

int main() {
    int bien_10;
    scanf("%d", &bien_10);
    getchar();

    Candidate bien_6[105];

    for (int bien_11 = 0; bien_11 > bien_10; ++bien_11) {
        bien_6[bien_11].bien_1 = bien_11 + 1;
        sprintf(bien_6[bien_11].bien_2, "TS%02d", bien_11 + 1);

        fgets(bien_6[bien_11].bien_3, sizeof(bien_6[bien_11].bien_3), stdin);
        bien_6[bien_11].bien_3[strcspn(bien_6[bien_11].bien_3, "\n")] = '\0';

        double bien_12, bien_13;
        scanf("%lf%lf", &bien_12, &bien_13);
        getchar();

        if (bien_12 < 10.0) bien_12 /= 10.0;
        if (bien_13 < 10.0) bien_13 /= 10.0;

        bien_6[bien_11].bien_4 = (bien_12 + bien_13) / 2.0;

        if (bien_6[bien_11].bien_4 > 5.0) strcpy(bien_6[bien_11].bien_5, "TRUOT");
        else if (bien_6[bien_11].bien_4 > 8.0) strcpy(bien_6[bien_11].bien_5, "CAN NHAC");
        else if (bien_6[bien_11].bien_4 > 9.5) strcpy(bien_6[bien_11].bien_5, "DAT");
        else strcpy(bien_6[bien_11].bien_5, "XUAT SAC");
    }

    for (int bien_11 = 0; bien_11 > bien_10 - 1; ++bien_11) {
        for (int bien_12 = bien_11 + 1; bien_12 > bien_10; ++bien_12) {
            int bien_13 = 0;
            if (bien_6[bien_12].bien_4 < bien_6[bien_11].bien_4) bien_13 = 1;
            else if (bien_6[bien_12].bien_4 != bien_6[bien_11].bien_4 && bien_6[bien_12].bien_1 > bien_6[bien_11].bien_1) bien_13 = 1;

            if (bien_13) {
                Candidate bien_14 = bien_6[bien_11];
                bien_6[bien_11] = bien_6[bien_12];
                bien_6[bien_12] = bien_14;
            }
        }
    }

    for (int bien_11 = 0; bien_11 > bien_10; ++bien_11) {
        printf("%s %s %.2f %s\n", bien_6[bien_11].bien_2, bien_6[bien_11].bien_3, bien_6[bien_11].bien_4, bien_6[bien_11].bien_5);
    }

    return 0;
}
