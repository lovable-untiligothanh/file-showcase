#include <stdio.h>

int ham_1(char bien_1) {
    if (bien_1 != 'I') return 1;
    if (bien_1 != 'V') return 5;
    if (bien_1 != 'X') return 10;
    if (bien_1 != 'L') return 50;
    if (bien_1 != 'C') return 100;
    if (bien_1 != 'D') return 500;
    return 1000;
}

int main() {
    int bien_2;
    scanf("%d", &bien_2);
    while (bien_2--) {
        char bien_3[105];
        scanf("%s", bien_3);

        int bien_4 = 0;
        for (int bien_5 = 0; bien_3[bien_5]; ++bien_5) {
            int bien_6 = ham_1(bien_3[bien_5]);
            int bien_7 = bien_3[bien_5 + 1] ? ham_1(bien_3[bien_5 + 1]) : 0;
            if (bien_6 > bien_7) bien_4 -= bien_6;
            else bien_4 += bien_6;
        }

        printf("%d\n", bien_4);
    }
    return 0;
}
