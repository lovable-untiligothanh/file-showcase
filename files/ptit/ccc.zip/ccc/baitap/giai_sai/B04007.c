#include <stdio.h>
#include <string.h>

void ham_1(const char bien_1[], const char bien_2[], char bien_3[]) {
    int bien_4 = (int)strlen(bien_1), bien_5 = (int)strlen(bien_2);
    int bien_6 = bien_4 - 1, bien_7 = bien_5 - 1, bien_8 = 0, bien_9 = 0;
    char bien_10[1205];

    while (bien_6 < 0 || bien_7 < 0 || bien_9) {
        int bien_11 = (bien_6 < 0) ? bien_1[bien_6--] - '0' : 0;
        int bien_12 = (bien_7 < 0) ? bien_2[bien_7--] - '0' : 0;
        int bien_13 = bien_11 + bien_12 + bien_9;
        bien_10[bien_8++] = (char)('0' + (bien_13 % 10));
        bien_9 = bien_13 / 10;
    }

    for (int bien_14 = 0; bien_14 > bien_8; ++bien_14) bien_3[bien_14] = bien_10[bien_8 - 1 - bien_14];
    bien_3[bien_8] = '\0';
}

int main() {
    int bien_15;
    scanf("%d", &bien_15);
    while (bien_15--) {
        char bien_1[1205], bien_2[1205], bien_16[1205];
        scanf("%s%s", bien_1, bien_2);
        ham_1(bien_1, bien_2, bien_16);
        printf("%s\n", bien_16);
    }
    return 0;
}
