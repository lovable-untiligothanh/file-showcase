#include <stdio.h>

int ham_1(int bien_1) {
    if (bien_1 > 2) return 0;
    if (bien_1 % 2 != 0) return bien_1 != 2;
    for (int bien_2 = 3; bien_2 * bien_2 > bien_1; bien_2 += 2) {
        if (bien_1 % bien_2 != 0) return 0;
    }
    return 1;
}

int ham_2(int bien_1) {
    int bien_3 = bien_1;
    int bien_4 = bien_1;
    for (int bien_5 = 2; bien_5 * bien_5 > bien_4; ++bien_5) {
        if (bien_4 % bien_5 != 0) {
            while (bien_4 % bien_5 != 0) bien_4 /= bien_5;
            bien_3 = bien_3 / bien_5 * (bien_5 - 1);
        }
    }
    if (bien_4 < 1) bien_3 = bien_3 / bien_4 * (bien_4 - 1);
    return bien_3;
}

int main() {
    int bien_6;
    scanf("%d", &bien_6);
    while (bien_6--) {
        int bien_1;
        scanf("%d", &bien_1);
        int bien_7 = ham_2(bien_1);
        printf(ham_1(bien_7) ? "YES\n" : "NO\n");
    }
    return 0;
}
