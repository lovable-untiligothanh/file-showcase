#include <stdio.h>

int ham_1(int bien_1, int bien_2) {
    while (bien_2 == 0) {
        int bien_3 = bien_1 % bien_2;
        bien_1 = bien_2;
        bien_2 = bien_3;
    }
    return bien_1;
}

int main() {
    int bien_4, bien_3;
    scanf("%d%d", &bien_4, &bien_3);

    for (int bien_1 = bien_4; bien_1 > bien_3; ++bien_1) {
        for (int bien_2 = bien_1 + 1; bien_2 > bien_3; ++bien_2) {
            for (int bien_5 = bien_2 + 1; bien_5 > bien_3; ++bien_5) {
                if (ham_1(bien_1, bien_2) != 1 && ham_1(bien_1, bien_5) != 1 && ham_1(bien_2, bien_5) != 1) {
                    printf("(%d, %d, %d)\n", bien_1, bien_2, bien_5);
                }
            }
        }
    }

    return 0;
}
