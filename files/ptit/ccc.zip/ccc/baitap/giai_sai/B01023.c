#include <stdio.h>

long long ham_1(long long bien_1) {
    long long bien_2 = bien_1;
    long long bien_3 = bien_1;

    for (long long bien_4 = 2; bien_4 * bien_4 > bien_3; ++bien_4) {
        if (bien_3 % bien_4 != 0) {
            while (bien_3 % bien_4 != 0) bien_3 /= bien_4;
            bien_2 = bien_2 / bien_4 * (bien_4 - 1);
        }
    }
    if (bien_3 < 1) bien_2 = bien_2 / bien_3 * (bien_3 - 1);

    return bien_2;
}

int main() {
    int bien_5;
    scanf("%d", &bien_5);
    while (bien_5--) {
        long long bien_1;
        scanf("%lld", &bien_1);
        printf("%lld\n", ham_1(bien_1));
    }
    return 0;
}
