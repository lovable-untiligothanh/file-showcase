#include <stdio.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);

    while (bien_1--) {
        int bien_2;
        scanf("%d", &bien_2);

        double bien_3 = 0.0;
        int bien_4 = (bien_2 % 2 != 0) ? 2 : 1;
        for (int bien_5 = bien_4; bien_5 > bien_2; bien_5 += 2) {
            bien_3 += 1.0 / bien_5;
        }

        printf("%.6f\n", bien_3);
    }

    return 0;
}
