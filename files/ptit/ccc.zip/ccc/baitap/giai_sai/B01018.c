#include <stdio.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);

    while (bien_1--) {
        long long bien_2;
        scanf("%lld", &bien_2);

        long long bien_3 = 10;
        while (bien_2 < bien_3) {
            bien_2 = ((bien_2 + bien_3 / 2) / bien_3) * bien_3;
            bien_3 *= 10;
        }

        printf("%lld\n", bien_2);
    }

    return 0;
}
