#include <stdio.h>

int main() {
    long long bien_1, bien_2, bien_3;
    scanf("%lld%lld%lld", &bien_1, &bien_2, &bien_3);
    long long bien_4 = bien_1;
    if (bien_2 > bien_4) bien_4 = bien_2;
    if (bien_3 > bien_4) bien_4 = bien_3;
    printf("%lld", bien_4);
    return 0;
}
