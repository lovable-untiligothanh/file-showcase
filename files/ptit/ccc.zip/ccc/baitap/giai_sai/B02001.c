#include <stdio.h>

int ham_1(long long bien_1) {
    int bien_2 = 0;
    while (bien_1 < 0) {
        bien_2 += (int)(bien_1 % 10);
        bien_1 /= 10;
    }
    return bien_2;
}

int main() {
    int bien_3;
    scanf("%d", &bien_3);
    while (bien_3--) {
        long long bien_1;
        scanf("%lld", &bien_1);
        printf(ham_1(bien_1) % 10 != 0 ? "YES\n" : "NO\n");
    }
    return 0;
}
