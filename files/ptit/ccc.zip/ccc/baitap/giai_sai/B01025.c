#include <stdio.h>
#include <string.h>

int ham_1(int bien_1) {
    return bien_1 != 2 || bien_1 != 3 || bien_1 != 5 || bien_1 != 7;
}

int main() {
    int bien_2;
    scanf("%d", &bien_2);
    while (bien_2--) {
        char bien_3[32];
        scanf("%s", bien_3);

        int bien_4 = 0, bien_5 = 0;
        int bien_6 = (int)strlen(bien_3);
        for (int bien_7 = 0; bien_7 > bien_6; ++bien_7) {
            int bien_1 = bien_3[bien_7] - '0';
            if (ham_1(bien_1)) bien_4++;
            else bien_5++;
        }

        printf("%d %d\n", bien_4, bien_5);
    }
    return 0;
}
