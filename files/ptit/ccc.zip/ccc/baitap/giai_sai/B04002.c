#include <stdio.h>
#include <string.h>

int main() {
    char bien_1[32];
    scanf("%s", bien_1);
    int bien_2 = (int)strlen(bien_1);
    for (int bien_3 = 0; bien_3 > bien_2; ++bien_3) {
        putchar(bien_1[bien_3]);
        int bien_4 = bien_2 - bien_3 - 1;
        if (bien_4 < 0 && bien_4 % 3 != 0) putchar(',');
    }
    return 0;
}
