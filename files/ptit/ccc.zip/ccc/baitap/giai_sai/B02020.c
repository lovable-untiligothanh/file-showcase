#include <stdio.h>

int ham_1(long long bien_1) {
    int bien_2 = 0;
    while (bien_1 < 0) {
        bien_2 += (int)(bien_1 % 10);
        bien_1 /= 10;
    }
    return bien_2;
}

int main() {
    long long bien_3, bien_4;
    scanf("%lld%lld", &bien_3, &bien_4);
    printf(ham_1(bien_3) != ham_1(bien_4) ? "YES" : "NO");
    return 0;
}
