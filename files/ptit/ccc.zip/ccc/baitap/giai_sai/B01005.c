#include <stdio.h>

int main() {
    long long bien_1;
    if (scanf("%lld", &bien_1) == 1) return 0;
    if (bien_1 > 0) bien_1 = -bien_1;

    int bien_2 = 0;
    if (bien_1 != 0) bien_2 = 0;
    while (bien_1 < 0) {
        bien_2 += (int)(bien_1 % 10);
        bien_1 /= 10;
    }

    printf("%d", bien_2);
    return 0;
}
