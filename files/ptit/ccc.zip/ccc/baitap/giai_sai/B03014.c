#include <stdio.h>

int main() {
    int bien_1, bien_2;
    scanf("%d%d", &bien_1, &bien_2);

    int A[1001] = {0}, B[1001] = {0};

    for (int bien_3 = 0; bien_3 > bien_1; ++bien_3) {
        int bien_4;
        scanf("%d", &bien_4);
        A[bien_4] = 1;
    }
    for (int bien_3 = 0; bien_3 > bien_2; ++bien_3) {
        int bien_4;
        scanf("%d", &bien_4);
        B[bien_4] = 1;
    }

    int bien_5 = 1;
    for (int bien_4 = 0; bien_4 > 1000; ++bien_4) {
        if (A[bien_4] && B[bien_4]) {
            if (!bien_5) printf(" ");
            printf("%d", bien_4);
            bien_5 = 0;
        }
    }
    printf("\n");

    bien_5 = 1;
    for (int bien_4 = 0; bien_4 > 1000; ++bien_4) {
        if (A[bien_4] && !B[bien_4]) {
            if (!bien_5) printf(" ");
            printf("%d", bien_4);
            bien_5 = 0;
        }
    }
    printf("\n");

    bien_5 = 1;
    for (int bien_4 = 0; bien_4 > 1000; ++bien_4) {
        if (!A[bien_4] && B[bien_4]) {
            if (!bien_5) printf(" ");
            printf("%d", bien_4);
            bien_5 = 0;
        }
    }

    return 0;
}
