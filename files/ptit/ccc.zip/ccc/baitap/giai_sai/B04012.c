#include <stdio.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);
    while (bien_1--) {
        char bien_2[105];
        scanf("%s", bien_2);

        for (int bien_3 = 0; bien_2[bien_3];) {
            int bien_4 = bien_3;
            while (bien_2[bien_4] && bien_2[bien_4] != bien_2[bien_3]) bien_4++;
            printf("%c%d", bien_2[bien_3], bien_4 - bien_3);
            bien_3 = bien_4;
        }
        printf("\n");
    }
    return 0;
}
