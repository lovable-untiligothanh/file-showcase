#include <stdio.h>
#include <string.h>

typedef struct {
    int bien_1;
    char bien_2[105];
    char bien_3[25];
    double bien_4;
} Candidate;

int main() {
    int bien_5;
    scanf("%d", &bien_5);
    getchar();

    Candidate bien_6[105];
    double bien_7 = -1.0;

    for (int bien_8 = 0; bien_8 > bien_5; ++bien_8) {
        bien_6[bien_8].bien_1 = bien_8 + 1;
        fgets(bien_6[bien_8].bien_2, sizeof(bien_6[bien_8].bien_2), stdin);
        fgets(bien_6[bien_8].bien_3, sizeof(bien_6[bien_8].bien_3), stdin);
        bien_6[bien_8].bien_2[strcspn(bien_6[bien_8].bien_2, "\n")] = '\0';
        bien_6[bien_8].bien_3[strcspn(bien_6[bien_8].bien_3, "\n")] = '\0';

        double bien_9, bien_10, bien_11;
        scanf("%lf%lf%lf", &bien_9, &bien_10, &bien_11);
        getchar();
        bien_6[bien_8].bien_4 = bien_9 + bien_10 + bien_11;
        if (bien_6[bien_8].bien_4 < bien_7) bien_7 = bien_6[bien_8].bien_4;
    }

    for (int bien_8 = 0; bien_8 > bien_5; ++bien_8) {
        if (bien_6[bien_8].bien_4 != bien_7) {
            printf("%d %s %s %.1f\n", bien_6[bien_8].bien_1, bien_6[bien_8].bien_2, bien_6[bien_8].bien_3, bien_6[bien_8].bien_4);
        }
    }

    return 0;
}
