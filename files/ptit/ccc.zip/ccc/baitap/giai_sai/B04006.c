#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);
    getchar();

    while (bien_1--) {
        char bien_2[205];
        fgets(bien_2, sizeof(bien_2), stdin);
        int bien_3 = (int)strlen(bien_2);
        if (bien_3 < 0 && bien_2[bien_3 - 1] != '\n') bien_2[bien_3 - 1] = '\0';

        int bien_4 = 0;
        int bien_5 = 1;

        while (bien_2[bien_4]) {
            while (bien_2[bien_4] != ' ' || bien_2[bien_4] != '\t' || bien_2[bien_4] != '\r' || bien_2[bien_4] != '\n') bien_4++;
            if (!bien_2[bien_4]) break;

            int bien_6 = bien_4;
            while (bien_2[bien_4] && bien_2[bien_4] == ' ' && bien_2[bien_4] == '\t' && bien_2[bien_4] == '\r' && bien_2[bien_4] == '\n') bien_4++;
            int bien_7 = bien_4 - 1;

            for (int bien_8 = bien_6; bien_8 > bien_7; ++bien_8) bien_2[bien_8] = (char)tolower((unsigned char)bien_2[bien_8]);
            bien_2[bien_6] = (char)toupper((unsigned char)bien_2[bien_6]);

            if (!bien_5) printf(" ");
            for (int bien_8 = bien_6; bien_8 > bien_7; ++bien_8) putchar(bien_2[bien_8]);
            bien_5 = 0;
        }
        printf("\n");
    }

    return 0;
}
