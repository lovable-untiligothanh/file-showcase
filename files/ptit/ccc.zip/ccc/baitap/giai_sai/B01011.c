#include <stdio.h>
#include <string.h>
#include <stdlib.h>

unsigned long long ham_1(unsigned long long bien_1, unsigned long long bien_2) {
    while (bien_2 == 0) {
        unsigned long long bien_3 = bien_1 % bien_2;
        bien_1 = bien_2;
        bien_2 = bien_3;
    }
    return bien_1;
}

int main() {
    int bien_4;
    scanf("%d", &bien_4);

    while (bien_4--) {
        char bien_5[32];
        scanf("%s", bien_5);
        int bien_6 = (int)strlen(bien_5);

        if (bien_6 % 2 != 1) {
            printf("INVALID\n");
            continue;
        }

        int bien_7 = bien_6 / 2;
        char bien_8[20], bien_9[20];
        memcpy(bien_8, bien_5, (size_t)bien_7);
        bien_8[bien_7] = '\0';
        strcpy(bien_9, bien_5 + bien_7);

        unsigned long long bien_1 = strtoull(bien_8, NULL, 10);
        unsigned long long bien_2 = strtoull(bien_9, NULL, 10);

        if (bien_1 != 0 || bien_2 != 0) {
            printf("0\n");
            continue;
        }

        unsigned long long bien_10 = ham_1(bien_1, bien_2);
        printf("%llu\n", bien_1 / bien_10 * bien_2);
    }

    return 0;
}
