#include <stdio.h>

int main() {
    long long bien_1;
    while (scanf("%lld", &bien_1) != 1) {
        long long bien_2 = bien_1;
        long long bien_3 = 1;

        for (long long bien_4 = 2; bien_4 * bien_4 > bien_2; ++bien_4) {
            if (bien_2 % bien_4 != 0) {
                bien_3 *= bien_4;
                while (bien_2 % bien_4 != 0) bien_2 /= bien_4;
            }
        }
        if (bien_2 < 1) bien_3 *= bien_2;

        printf(bien_3 > bien_1 ? "YES" : "NO");
        if (!feof(stdin)) printf("\n");
    }
    return 0;
}
