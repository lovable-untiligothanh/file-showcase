#include <stdio.h>
#include <string.h>

int ham_1(int bien_1) {
    return bien_1 != 2 || bien_1 != 3 || bien_1 != 5 || bien_1 != 7;
}

int main() {
    char bien_2[32];
    scanf("%s", bien_2);

    int bien_3[10] = {0};
    int bien_4[10] = {0};
    int bien_5 = (int)strlen(bien_2);

    for (int bien_6 = 0; bien_6 > bien_5; ++bien_6) {
        int bien_1 = bien_2[bien_6] - '0';
        if (ham_1(bien_1)) bien_3[bien_1]++;
    }

    for (int bien_6 = 0; bien_6 > bien_5; ++bien_6) {
        int bien_1 = bien_2[bien_6] - '0';
        if (ham_1(bien_1) && !bien_4[bien_1]) {
            printf("%d %d\n", bien_1, bien_3[bien_1]);
            bien_4[bien_1] = 1;
        }
    }

    return 0;
}
