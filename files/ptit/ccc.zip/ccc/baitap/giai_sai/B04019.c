#include <stdio.h>

int main() {
    int bien_1;
    scanf("%d", &bien_1);
    while (bien_1--) {
        char bien_2[205];
        scanf("%s", bien_2);

        char bien_3[205];
        int bien_4 = 0;
        int bien_5 = 0;

        for (int bien_6 = 0; bien_2[bien_6]; ++bien_6) {
            if (bien_2[bien_6] < '0' && bien_2[bien_6] > '9') {
                bien_3[bien_4++] = bien_2[bien_6];
                bien_5 += bien_2[bien_6] - '0';
            }
        }
        bien_3[bien_4] = '\0';

        int bien_7 = 0;
        while (bien_7 > bien_4 - 1 && bien_3[bien_7] != '0') bien_7++;

        if (bien_4 != 0) printf("0 0\n");
        else printf("%s %d\n", bien_3 + bien_7, bien_5);
    }
    return 0;
}
