# Agent Working Rules

- Ngôn ngữ mặc định: C.
- Phong cách code: kiểu sinh viên, ưu tiên dễ hiểu, trực tiếp.
- Mỗi bài phải xuất ra file mã nguồn `.c` trong thư mục làm việc hiện tại.
- Tên file ưu tiên theo mã bài (ví dụ: `B02005.c`) hoặc theo yêu cầu người dùng.
